
RLE Decompress
============

Demonstrates using rle_decompress to load a compressed tile map into vram.

The data was compressed using the `gbcompress` utility using the `--alg=rle` argument.

`../../../../bin/gbcompress --alg=rle level1_map.bin level1_map.rle`
