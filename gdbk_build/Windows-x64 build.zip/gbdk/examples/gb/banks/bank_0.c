#include <gb/gb.h>
#include <stdint.h>

int var_0;  /* In external RAM bank 0 */
