
GBDecompress
============

Demonstrates using gbdecompress to load a compressed tile set into vram.

The tileset was compressed during export from GBTD by checking the 
GB-compress checkbox in the export settings panel.
