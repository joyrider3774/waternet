
An example project showing how to use 'incbin.h' to include binary files into C source files.


The 4 color .png files were exported to .bin format (2bpp gb) using the gimp plugin listed below.
There are many other tools which can also do the conversion.

https://github.com/bbbbbr/gimp-rom-bin
